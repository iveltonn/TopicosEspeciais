#include <iostream>
#include <string> 


struct Pessoa {
    std::string nome;
    int idade;
    float altura;
};

int main() {

    Pessoa pessoa1;


    pessoa1.nome = "João";
    pessoa1.idade = 30;
    pessoa1.altura = 1.75;

    // Imprimindo os dados na tela
    std::cout << "Nome: " << pessoa1.nome << std::endl;
    std::cout << "Idade: " << pessoa1.idade << " anos" << std::endl;
    std::cout << "Altura: " << pessoa1.altura << " metros" << std::endl;

    return 0;
}

