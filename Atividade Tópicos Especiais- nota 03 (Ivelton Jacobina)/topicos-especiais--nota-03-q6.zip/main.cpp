#include <iostream>

int main() {
    const int tamanhoArray = 5; 
    int meuArray[tamanhoArray]; 

    
    for (int i = 0; i < tamanhoArray; i++) {
        std::cout << "Digite o valor para o elemento " << i << ": ";
        std::cin >> meuArray[i];
    }

    
    std::cout << "Valores do array: ";
    for (int i = 0; i < tamanhoArray; i++) {
        std::cout << meuArray[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}

