#include <iostream>

int main() {
   
    for (int i = 1; i <= 5; ++i) {
        for (int j = 1; j <= 5; ++j) {
            
            int produto = i * j;
            std::cout << i << " * " << j << " = " << produto << "\t";
        }
        // Após imprimir uma linha completa da tabela, vá para a próxima linha.
        std::cout << std::endl;
    }

    return 0;
}

