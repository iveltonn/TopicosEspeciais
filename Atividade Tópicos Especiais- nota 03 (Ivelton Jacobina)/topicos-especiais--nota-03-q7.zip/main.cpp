#include <iostream>
#include <cstdlib>
#include <ctime>

int main() {
   
    srand(static_cast<unsigned int>(time(nullptr)));

    int numeroAleatorio = rand() % 10 + 1;

    int suposicao;
    int tentativas = 0;

    do {
        
        std::cout << "Adivinhe um número entre 1 e 10: ";
        std::cin >> suposicao;

        tentativas++;

        
        if (suposicao == numeroAleatorio) {
            std::cout << "Parabéns! Você acertou o número em " << tentativas << " tentativas." << std::endl;
        } else {
            std::cout << "Tente novamente." << std::endl;
        }

    } while (suposicao != numeroAleatorio);

    return 0;
}

