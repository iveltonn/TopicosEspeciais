#include <iostream>


int calcularQuadrado(int numero) {
    return numero * numero;
}

int main() {
    int numero;

    std::cout << "Por favor, insira um número inteiro: ";
    std::cin >> numero;
    
    
    int quadrado = calcularQuadrado(numero);
    
   
    std::cout << "O quadrado de " << numero << " é: " << quadrado << std::endl;
    
    return 0;
}

