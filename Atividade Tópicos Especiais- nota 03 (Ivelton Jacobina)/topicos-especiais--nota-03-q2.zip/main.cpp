#include <iostream>

int main() {
    int numero = 1;

    while (numero <= 10) {
        std::cout << numero << " ";
        numero++;
    }

    std::cout << std::endl; 
    
    return 0;
}

