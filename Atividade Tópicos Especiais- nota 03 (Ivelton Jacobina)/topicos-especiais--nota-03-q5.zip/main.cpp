#include <iostream>

int main() {
    int minhaVariavel = 42; 
    int *ponteiroParaVariavel = &minhaVariavel; 

    
    std::cout << "Valor da variável: " << minhaVariavel << std::endl;
    std::cout << "Endereço de memória da variável: " << ponteiroParaVariavel << std::endl;

    return 0;
}

